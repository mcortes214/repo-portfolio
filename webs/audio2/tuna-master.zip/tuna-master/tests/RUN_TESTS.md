# Running tests

Tests depend on the [Jasmine](http://jasmine.github.io/) testing framework,
currently using v. 2.3.4, and are run in the browser.

The Jasmine files are loaded on the fly from the CloudFlare
CDN. Load the `$TUNA_BRANCH_ROOT/tests/online-runner.html` file in your
browser: you should see a test output page with zero failures.
